if (window.location.pathname.includes("blog.html")) {
    var str = document.getElementsByTagName('div')[0].innerHTML.toString();
    var i = 0;
    document.getElementsByTagName('div')[0].innerHTML = "";

    setTimeout(function () {
        var se = setInterval(function () {
            i++;
            document.getElementsByTagName('div')[0].innerHTML = str.slice(0, i) + "|";
            if (i == str.length) {
                clearInterval(se);
                document.getElementsByTagName('div')[0].innerHTML = str;
            }
        }, 10);
    }, 0);
}

$('.featured-work ul li').on('click', function () {

    $(this).addClass('active').siblings().removeClass('active');
    console.log($(this).data('class'));
    if ($(this).data('class') === 'all') {
        $('.shuffle-images .col-md').css('opacity', 1)
    } else {
        $('.shuffle-images .col-md').css('opacity', '.08')
        $($(this).data('class')).parent().css('opacity', 1)
    }
});